<!DOCTYPE HTML>
<html>
<?php include_once('./templete/overall/head.php'); ?>
<body class="cbp-spmenu-push">
<div class="main-content">
<?php include_once('./templete/overall/leftnav.php'); ?>
<?php include_once('./templete/overall/header.php'); ?>