<?php
	include_once('./rvcore_web/init.php');
//	protect_page();
//	logged_in_redirect();
	include_once('./templete/header.php');
?>

<!-- main content start-->
<div id="page-wrapper">
	<div class="main-page">




	</div>
</div>
	
<?php include_once('./templete//footer.php'); ?>
	
<!-- side nav js -->
<script src='js/SidebarNav.min.js' type='text/javascript'></script>
<script>
  $('.sidebar-menu').SidebarNav()
</script>
<!-- //side nav js -->

<!-- Bootstrap Core JavaScript -->
 <script src="js/bootstrap.js"> </script>
<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>